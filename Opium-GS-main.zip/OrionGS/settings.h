#pragma once

// Due to licensing issues I may not include the whole source :skull:
// #define USING_EZAntiCheat

#define MAX_ZIPLINE_ENTER_DISTANCE 50
#define NO_DEDISES

//#define USE_BACKEND
#define USE_BACKEND_DEV
//#define PELOG